============================================
                GlassPwn for
           Aero Glass for Win8.1
                Version 1.0

            Team PWNAGE (C) 2014
                       PwnMaster
                        SpaceGuy
============================================

GlassPwn is an application to disable
restrictions on Aero Glass for Windows 8.1.

It's very simple to use. Run the EXE file
and follow the wizard instructions. Your
Desktop Window Manager should restart itself
and after that you will have your features
unrestricted.

If you have any problems e-mail me at our
team address: pwnmaster2014@ya.ru

Hope you like our releases!


Changelog:
Version 1.0:
Initial release.